$(document).ready(function() {
    $("#regForm").submit(function(event) {
        var isValid = true;
        var errorMessage = "";

        // 用户名校验
        var userName = $("#userName").val();
        if (userName.length < 2 || userName.length > 15) {
            errorMessage += "用户名为2~15位字符\n";
            isValid = false;
        }

        // 密码校验
        var passWord = $("#passWord").val();
        if (passWord.length < 4 || passWord.length > 8) {
            errorMessage += "密码为4~8位字符\n";
            isValid = false;
        }

        // 确认密码校验
        var c_passWord = $("#c_passWord").val();
        if (c_passWord !== passWord) {
            errorMessage += "两次输入的密码不一致\n";
            isValid = false;
        }

        // 姓名校验
        var name = $("#name").val();
        if (name.length < 2 || name.length > 8) {
            errorMessage += "姓名为2~8位字符\n";
            isValid = false;
        }

        // 年龄校验
        var age = $("#age").val();
        if (!age) {
            errorMessage += "年龄必填\n";
            isValid = false;
        }

        // 电话校验
        var tell = $("#tell").val();
        if (!tell) {
            errorMessage += "电话必填\n";
            isValid = false;
        }

        // 地址校验
        var address = $("#address").val();
        if (!address) {
            errorMessage += "地址必填\n";
            isValid = false;
        }

        if (!isValid) {
            event.preventDefault(); // 阻止表单提交
            alert(errorMessage);   // 显示所有错误信息
        }
    });
});


$(document).ready(function() {
    $("#loginForm").submit(function(event) {
        var userName = $("#l_userName").val();
        var passWord = $("#l_passWord").val();
        var code = $("#ck_code").val();

        if (userName === "" || passWord === "" || code === "") {
            alert("用户名、密码和验证码不能为空！");
            event.preventDefault(); // 阻止表单提交
        }
    });
});