package com.shop.service;


import com.shop.bean.Goods;
import com.shop.bean.PageBean;



import java.util.List;

public interface GoodsService {
    // 获取商品总数
    long goodsReadCount(String goodsname, Integer catalogId);




    public List<Goods> goodsList(PageBean pageBean, Integer catalogId, String goodsname);



    // 增加商品
    boolean goodsAdd(Goods goods);

    // 根据商品id查找商品信息
    Goods findGoodsById(int goodsId);

    // 根据商品名称查找商品是否存在
    boolean findGoodsByGoodsName(String goodsName);

    // 更新商品信息
    boolean goodsUpdate(Goods goods);

    // 根据id删除商品
    boolean goodsDelById(int goodsId);

    // 根据id串查询图片id串
    String findimgIdByIds(String ids);

    // 批量删除商品
    boolean goodsBatDelById(String ids);

    // 随机获取指定数量书
    List<Goods> goodsList(int num);

    // 获取指定数量新添加的商品
    List<Goods> newGoodss(int num);
}
