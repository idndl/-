/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80039
 Source Host           : localhost:3306
 Source Schema         : goodsshop

 Target Server Type    : MySQL
 Target Server Version : 80039
 File Encoding         : 65001

 Date: 05/12/2024 21:01:08
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for s_admin
-- ----------------------------
DROP TABLE IF EXISTS `s_admin`;
CREATE TABLE `s_admin`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `userName` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `passWord` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `lastLoginTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of s_admin
-- ----------------------------
INSERT INTO `s_admin` VALUES (2, 'admin', 'admin', '管理员', '2024-12-05 18:12:11');

-- ----------------------------
-- Table structure for s_catalog
-- ----------------------------
DROP TABLE IF EXISTS `s_catalog`;
CREATE TABLE `s_catalog`  (
  `catalogId` int NOT NULL AUTO_INCREMENT,
  `catalogName` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`catalogId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of s_catalog
-- ----------------------------
INSERT INTO `s_catalog` VALUES (1, '图书');
INSERT INTO `s_catalog` VALUES (2, '手机');
INSERT INTO `s_catalog` VALUES (3, '服装');

-- ----------------------------
-- Table structure for s_goods
-- ----------------------------
DROP TABLE IF EXISTS `s_goods`;
CREATE TABLE `s_goods`  (
  `goodsId` int NOT NULL AUTO_INCREMENT,
  `catalogId` int NOT NULL,
  `goodsName` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '',
  `origin` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '',
  `supplier` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '',
  `price` double(10, 2) NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL,
  `imgId` int NOT NULL,
  `addTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`goodsId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 75 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of s_goods
-- ----------------------------
INSERT INTO `s_goods` VALUES (62, 2, 'iPhone16pro', '中国', '苹果公司', 8999.00, NULL, 76, '2024-12-04 22:55:43');
INSERT INTO `s_goods` VALUES (63, 1, '三体', '中国', '重庆出版社', 56.80, NULL, 77, '2024-12-04 22:58:17');
INSERT INTO `s_goods` VALUES (64, 1, '所罗门王的指环', '[奥] 康拉德·洛伦茨', '中信出版社', 33.30, NULL, 78, '2024-12-04 23:06:20');
INSERT INTO `s_goods` VALUES (65, 1, '时间简史', '英国', '湖南科学技术出版社', 68.00, NULL, 79, '2024-12-04 23:08:09');
INSERT INTO `s_goods` VALUES (66, 2, '华为Mate XT 非凡大师', '中国', '华为手机公司', 27999.00, NULL, 80, '2024-12-04 23:10:59');
INSERT INTO `s_goods` VALUES (67, 2, '小米 MIX Fold 4', '北京', '小米公司', 8997.00, NULL, 81, '2024-12-04 23:12:39');
INSERT INTO `s_goods` VALUES (68, 2, 'vivo X Fold3 Pro', '中国', 'vivo公司', 8499.00, NULL, 82, '2024-12-04 23:13:57');
INSERT INTO `s_goods` VALUES (69, 2, '红米k70pro', '中国', '红米手机公司', 3999.00, NULL, 83, '2024-12-04 23:15:46');
INSERT INTO `s_goods` VALUES (70, 3, '女款连帽风衣', '中国', '服装公司', 259.00, NULL, 84, '2024-12-04 23:18:14');
INSERT INTO `s_goods` VALUES (71, 3, '女款窄版阔腿牛仔裤', '中国', '服装公司', 69.00, NULL, 85, '2024-12-04 23:19:22');
INSERT INTO `s_goods` VALUES (72, 3, '男款秋冬加绒长裤', '中国', '服装公司', 59.00, NULL, 86, '2024-12-04 23:20:20');
INSERT INTO `s_goods` VALUES (73, 3, '男款圆领卫衣', '中国', '服装公司', 158.00, NULL, 87, '2024-12-04 23:21:12');

-- ----------------------------
-- Table structure for s_order
-- ----------------------------
DROP TABLE IF EXISTS `s_order`;
CREATE TABLE `s_order`  (
  `orderId` int NOT NULL AUTO_INCREMENT,
  `orderNum` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '',
  `userId` int NOT NULL,
  `orderDate` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `money` double(10, 2) NOT NULL DEFAULT 0.00,
  `orderStatus` int NOT NULL,
  PRIMARY KEY (`orderId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of s_order
-- ----------------------------
INSERT INTO `s_order` VALUES (1, '202409261544415841968822923', 8, '2024-09-26 15:44:41', 3999.00, 2);
INSERT INTO `s_order` VALUES (2, '20240926200757859438420559', 1, '2024-09-26 20:07:57', 33.30, 1);
INSERT INTO `s_order` VALUES (3, '20241205125242910496370486', 9, '2024-12-05 12:52:42', 8555.80, 1);

-- ----------------------------
-- Table structure for s_orderitem
-- ----------------------------
DROP TABLE IF EXISTS `s_orderitem`;
CREATE TABLE `s_orderitem`  (
  `itemId` int NOT NULL AUTO_INCREMENT,
  `goodsId` int NOT NULL,
  `orderId` int NOT NULL DEFAULT 0,
  `quantity` int NOT NULL DEFAULT 0,
  PRIMARY KEY (`itemId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of s_orderitem
-- ----------------------------
INSERT INTO `s_orderitem` VALUES (1, 57, 1, 1);
INSERT INTO `s_orderitem` VALUES (2, 48, 2, 1);
INSERT INTO `s_orderitem` VALUES (3, 68, 3, 1);
INSERT INTO `s_orderitem` VALUES (4, 63, 3, 1);

-- ----------------------------
-- Table structure for s_uploadimg
-- ----------------------------
DROP TABLE IF EXISTS `s_uploadimg`;
CREATE TABLE `s_uploadimg`  (
  `imgId` int NOT NULL AUTO_INCREMENT,
  `imgName` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `imgSrc` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `imgType` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`imgId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 89 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of s_uploadimg
-- ----------------------------
INSERT INTO `s_uploadimg` VALUES (67, 'a348d4a5f9d94923bf20ea8604837178.png', 'images/goods/goodsimg/a348d4a5f9d94923bf20ea8604837178.png', 'image/png');
INSERT INTO `s_uploadimg` VALUES (68, 'b5b88bce978b4ed997bdc8f93040bb4f.jpg', 'images/goods/goodsimg/b5b88bce978b4ed997bdc8f93040bb4f.jpg', 'image/jpeg');
INSERT INTO `s_uploadimg` VALUES (76, '310d13eb414e4d0eb76a21c6279c74c1.png', 'images/front/goodsimg/310d13eb414e4d0eb76a21c6279c74c1.png', 'image/png');
INSERT INTO `s_uploadimg` VALUES (77, '5af33cfbc1944846af7bba5a9ad1de5d.png', 'images/front/goodsimg/5af33cfbc1944846af7bba5a9ad1de5d.png', 'image/png');
INSERT INTO `s_uploadimg` VALUES (78, 'b28ac0e943f147e2aab708392762a22b.jpg', 'images/front/goodsimg/b28ac0e943f147e2aab708392762a22b.jpg', 'image/jpeg');
INSERT INTO `s_uploadimg` VALUES (79, 'd15e27480ee84f038ef891474b2bf07b.jpg', 'images/front/goodsimg/d15e27480ee84f038ef891474b2bf07b.jpg', 'image/jpeg');
INSERT INTO `s_uploadimg` VALUES (80, '481e9962b7f3407fadfb3d85b90ca528.png', 'images/front/goodsimg/481e9962b7f3407fadfb3d85b90ca528.png', 'image/png');
INSERT INTO `s_uploadimg` VALUES (81, '7cba488f072341ed83f04a9ccf119704.png', 'images/front/goodsimg/7cba488f072341ed83f04a9ccf119704.png', 'image/png');
INSERT INTO `s_uploadimg` VALUES (82, '614598b9ab6f478f80432c5e98a8f92e.png', 'images/front/goodsimg/614598b9ab6f478f80432c5e98a8f92e.png', 'image/png');
INSERT INTO `s_uploadimg` VALUES (83, '023102638c7549838a7b47015282118d.png', 'images/front/goodsimg/023102638c7549838a7b47015282118d.png', 'image/png');
INSERT INTO `s_uploadimg` VALUES (84, '7079f7b113ae4c27b1a68710f2b172b7.png', 'images/front/goodsimg/7079f7b113ae4c27b1a68710f2b172b7.png', 'image/png');
INSERT INTO `s_uploadimg` VALUES (85, '61a0618bcb094c15879303fda8895d1b.png', 'images/front/goodsimg/61a0618bcb094c15879303fda8895d1b.png', 'image/png');
INSERT INTO `s_uploadimg` VALUES (86, 'e203a1e0b09b4df08175ff2d19e5dd59.png', 'images/front/goodsimg/e203a1e0b09b4df08175ff2d19e5dd59.png', 'image/png');
INSERT INTO `s_uploadimg` VALUES (87, '4bd68e14d2ff4b2eb017211396ee0443.png', 'images/front/goodsimg/4bd68e14d2ff4b2eb017211396ee0443.png', 'image/png');

-- ----------------------------
-- Table structure for s_user
-- ----------------------------
DROP TABLE IF EXISTS `s_user`;
CREATE TABLE `s_user`  (
  `userId` int NOT NULL AUTO_INCREMENT,
  `userName` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `userPassWord` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `name` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '',
  `sex` varchar(2) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `age` int NOT NULL,
  `tell` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `address` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `enabled` varchar(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`userId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of s_user
-- ----------------------------
INSERT INTO `s_user` VALUES (1, 'user', '1234', '张三', '女', 22, '11800000000', '北京', 'y');
INSERT INTO `s_user` VALUES (2, 'dsfsd', '1234', 'fsdaf', '男', 32, '11900000000', '广东', 'n');
INSERT INTO `s_user` VALUES (3, 'gggg', 'gggggg', 'gggggg', '男', 1, '12000000000', '深圳', 'n');
INSERT INTO `s_user` VALUES (4, 'user2', '1234', '测试用户', '女', 32, '12100000000', '上海', 'y');
INSERT INTO `s_user` VALUES (5, 'panfei', '1234', '潘飞', '男', 22, '12200000000', '安徽', 'y');
INSERT INTO `s_user` VALUES (6, 'cqxh', '1234', '唐辉煌', '男', 25, '12300000000', '山西', 'y');
INSERT INTO `s_user` VALUES (7, 'zzz123', '123456', '王德发', '男', 20, '12345678901', '重庆', 'y');
INSERT INTO `s_user` VALUES (8, 'lisi', '123456', '李四', '男', 23, '13302747116', '四川', 'y');
INSERT INTO `s_user` VALUES (9, 'ttq', 'ttqttq', '谭涛强', '男', 18, '123456789', '广州', 'y');

SET FOREIGN_KEY_CHECKS = 1;
